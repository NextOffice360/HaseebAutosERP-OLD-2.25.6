# Haseeb Autos — v2.25.8 CHANGELOG

**Date:** 2026-09-24 · **Version:** `2.25.8` (Utils.gs ▸ `VERSION`)
**Base:** v2.25.7 → is build mein (a) performance audit ke liye **instrumentation + harness**,
(b) user ki baar-baar wali shikayat — **left sidebar collapse** — ki **asli jarr ka fix**.

---

## 1 ▸ SIDEBAR — asli bug reproduce + fix (req 12–15) — ✅

**Shikayat:** "partially collapsed par icon + text dikhta rehta hai; width kam nahi hoti."

**Reproduce (naya audit script, 5 viewports):** collapse button dabane par `shell.collapsed` class
lagti thi magar **width 256px hi rehti thi** aur label `display:block` — sirf **reload** ke baad
64px hoti thi. Asli wajah: CSS mein `.shell.collapsed .sidebar:hover{width:256px}` tha; collapse
button sidebar ke andar hai, is liye pointer sidebar par hi rehta hai → hover-expand foran lagu →
user ko **icons + text (256px)** hi dikhta tha. Doosri wajah: nav labels (`h('span', null, label)`)
par koi class nahi thi, CSS sirf `.sb-name`/`.sb-user-meta` chhupata tha — items ke text
**64px rail mein clip** hote thay.

**Fix (shared logic — CSS + ek state function):**
* Nav labels ko **`.sb-txt`** class (menu-builder tree, children aur built-in nav — teenon jagah).
* **Rail = sirf icons:** `.shell.collapsed` mein `.sb-txt/.sb-name/.sb-user-meta/.sb-group/.nk`
  `display:none`; rail width **64px**; brand vertical (34px logo) + collapse button 24px.
* **Hover-expand hata diya** — rail ab hover par bhi 64px icons-only rehta hai; naam **tooltip**
  se (`data-tip` + CSS ::after; `title` barqarar — a11y).
* **State model ek jagah:** `applySb()` — breakpoint (≥901px desktop / ≤900px off-canvas) +
  saved preference → `shell.collapsed` + **`dataset.sbMode = expanded|rail|offcanvas`** + aria.
  `matchMedia` change par re-apply + off-canvas band.
* **Persistence:** preference `ha.sbCollapsed` — page change/reload par wahi. **Ctrl+B** ab isi
  function se chalta hai (pehle sirf class toggle hoti thi — save nahi hoti thi, aria sync nahi thi).
* **Mobile (≤900px):** collapsed rules **neutralize** (off-canvas drawer hamesha **poora**,
  icons+text) — desktop ka rail pref drawer ko shrink nahi karta (req 14).
* Compact brand/metadata ab poore raaste dhoondhne par bhi mojood (`title`/`aria-label`) — koi
  feature nahi hataya.

**Gate `sidebar-states` (naya): 19 PASS / 0 FAIL (15s)** — expanded icon+text · rail icons-only
(width ≤72px, label `display:none`, rects 0) · **rail+hover bhi icons-only** · tooltip data ·
reload persist (dono states) · Ctrl+B save · route change par reset nahi · mobile off-canvas
band/open · scrim + Esc band · mobile drawer poore labels · resize cycle.

**Sensitivity proven:** purana behaviour inject karke gate **4 checks FAIL** (`rail: label display block`,
`rail+hover 256px`, `reload persist`, `wapas desktop`), fix ke sath **19/0**.

## 2 ▸ Performance audit ke liye harness + instrumentation (W0 — req 1) — ✅

* **`tools/quick.sh <gate…>`** — per-gate **timeout (default 150s)**; hang par sirf us gate ko
  maarta hai (sandbox atakta nahi); sirf summary; **na-registered gate ko FAIL** karta hai
  (warna jhoota "green").
* **`API.call` instrumentation (W0.T2)** — `API.call` ab wrapper hai: `_begin → _call → _end`.
  Record: calls · ok/fail · action-wise count · **duplicates** (same action+payload jab pehli call
  chalu ho) · in-flight peak · times (p50/p95/max) · slow list. Dekhne ke liye
  `API.statsSummary()` / `window.__apiStats`, zero karne ke liye `API.statsReset()`.
  **Behaviour bilkul nahi badla** (test: instrumented return === direct mock return).
  Gate `api-instrument` — **14 PASS / 0 FAIL (4s)**.
* **`tools/test_perf_baseline.js` (W0.T3)** — 10 routes ka baseline → `tmp/perf-baseline.json`
  (calls/dups/p50/p95 per route; baad mein improvement isi se naapi jayegi).

### Early findings (audit W1 ka pehla hissa — numbers)

| # | Finding | Number |
|---|---|---|
| E1 | `API.call` par dedupe/cache/in-flight guard **nahi** | 0 |
| E2 | API.call sites (36 files) | **438** |
| E3 | Dashboard khulte hi parallel calls | **6** |
| E4 | Har nav par `config.menu` dobara fetch | har nav |
| E5 | Do modal systems (UI2.modal 100 + UI.modal 19) | 119 sites |
| E6 | Demo baseline (p95) | **246ms** → matlab dard live transport/N+1/no-cache hai, rendering nahi |

## 3 ▸ Gates: 57 → **58** (do naye)

`api-instrument` (4s) · `sidebar-states` (15s) — dono register + fast feedback ke qareeb.

## Verification (is build ka)

`env -u HOME bash tools/verify.sh` — **ALL 58 GATES GREEN (1183s), EXIT=0** · log `tmp/verify258c.log`.
Is round ke mutalliqua gates: `sidebar-states` **19/0** · `api-instrument` **14/0** ·
`modals-close` ✔ · `layout-desktop` ✔ · `layout-mobile` ✔ · `layout-dark` ✔ · `static` ✔ ·
`smoke` ✔ (130s) · `e2e` 55/0 · `logic` 816/0.

## User-side check

* Desktop par sidebar collapse karein → **sirf icons** (64px), hover par bhi text wapas nahi aata
  (naam tooltip mein) · page badlein / reload karein → wahi state.
* Mobile par ☰ se drawer kholein → **poore naam** (chahe desktop par rail chuni ho).

## Aage (roadmap — aap ke 16-point spec par)

W1 audit (API/N+1/backend/timeout) → W2 shared fetch + `UI.run` busy UX + error/retry (v2.25.9) →
W3 dynamic deps (Country→State→City, AI provider) → W4 timestamps + configurable date/time →
W5 visibility + **backend/API-level** protection → T6.3 responsive matrix → W7 app-wide apply →
W8 verify. Tafseel: `TODO-PERF-SHARED-UI.md`.
