# Haseeb Autos — v2.25.10 CHANGELOG

**Date:** 2026-09-24 · **Version:** `2.25.10` (Utils.gs ▸ `VERSION`)
**Base:** v2.25.9 (shared fetch core) → is build mein **W2.T2: action-level busy / duplicate-submit / progress**
(aap ke 16-point spec ka wo hissa: *"loading sirf usi button par ho, duplicate submits block hon, aur user
ko kabhi na lage ke app freeze ho gayi"*).

---

## 1 ▸ Asli masla (audit pehle, phir code)

Audit (438 call-sites + har modal/drawer/offcanvas action) ne teen cheezein saaf ki:

1. **Busy-ness sirf global thi** — ek patli top bar (`UI.busy`) poori app ke liye. Yani user ko
   pata hi nahi chalta tha ke **kaun sa kaam** chal raha hai.
2. **Har page ka apna hack** — PO save mein `'Saving…'` + manual `disabled`, POS pay mein
   `'⏳ Processing…'`, Settings save mein `'Saving…'`, AI settings mein `'Saving…'`/`'Testing…'`.
   Sab ka behaviour thora mukhtalif, aur sab jagah available nahi.
3. **Bhaari writes par koi busy state hi nahi thi** — **GRN post (Post GRN F9)**, customers/suppliers
   save, users/groups save: dobara tap karne ka koi rok nahi tha → **double GRN / double stock**
   ka khatra. Yehi wo "button hang ho jata hai / dobara daba deta hoon" wali shikayat ki jarh hai.

## 2 ▸ Naya shared helper: `UI.run(el, fn, opts)`

Ek hi jagah (App_Core.html) — poori desktop app ke liye:

| Feature | Tafseel |
|---|---|
| **Sirf usi button par spinner** | `is-busy` + inline spinner + label swap (`Save PO` → `Saving PO…`); disabled + `aria-busy=true`. **App-wide overlay nahi** — yehi aap ki shart thi |
| **Duplicate-submit block** | Chalti hui call par naya tap **naya call nahi karta** — wahi promise wapas milti hai (`runStats().blocked` mein ginta hai). Writes par double post khatam |
| **Long-op progress** | Chalti hui call ke saath elapsed seconds: `GRN post ho raha hai · 4s`, 20s ke baad `(chal raha hai…)` |
| **Success / error state** | Kaamyabi par **✓** (+ `okLabel` ho to `✓Posted` / `✓Saved`), error par **✖**; flash ke baad button apni **asli** halat par (label + enabled + `aria-busy` hat jata hai) |
| **Min-busy 320ms** | Bohat tez call par bhi state jhatke se na ghume |
| **Safety timeout** | Default 120s — jawab na aaye to button wapas usable + toast ("dobara koshish kar sakte hain"); user hamesha ke liye phansa nahi rehta |
| **Sync actions** | Cancel/Close jaisi sync actions par koi busy UI nahi (jhatke se band) |

**Kill-switch:** `UI._features.run = false` (sensitivity proof ke liye).
**Stats:** `UI.runStats()` / `UI.runStats(true)` (reset) → `started · blocked · ok · err · stale · running`.

### Khud-ba-khud lagta hai (koi call-site change nahi)
`UI.modal` · `UI.drawer` · `UI2.modal` · `UI2.offcanvas` — in chaaron ke **har action button** par
shared wrapper lagi hui hai. Yani GRN (drawer), PO, SO, customers/suppliers/users modals, bulk-add,
invoice dialogs, settings modals — sab cover.

## 3 ▸ Purane per-page hacks hata diye (ab shared logic)

| Jagah | Pehle | Ab |
|---|---|---|
| GRN post | Koi busy state nahi | `busyLabel: 'GRN post ho raha hai'`, `okLabel: 'Posted'` — duplicate post block |
| PO save | Manual `'Saving…'` + disabled | `busyLabel: 'PO save ho raha hai'`, `okLabel: 'Saved'` (hack gaya) |
| Settings save | Manual `'Saving…'` + lbl restore | `UI.run(saveBtn, …)` |
| AI settings save / Test connection | Manual `'Saving…'` / `'Testing…'` | `UI.run(btn, …)` with `busyLabel` |
| **PWA POS pay (Complete)** | Manual `'⏳ Processing…'` | **`PWA.run`** — spinner + elapsed + duplicate-tap block (**double sale se bachao**) + ✓/✖ |

## 4 ▸ PWA bundle ka apna `PWA.run` (Pwa_Shell.html)

PWA apps (`pwa-pos/wh/fo/sm`) App_Core include **nahi** karte, is liye wahi contract waha bhi mojood hai:
`PWA.run(el, fn, opts)` + `PWA.runStats()` + `PWA._features.run` — POS "✓ Complete" isi par chalta hai.

## 5 ▸ Naya gate: `ui-run` (34 checks, ~12s)

`tools/test_ui_run.js` — busy state sirf usi button par · spinner + label swap · duplicate block
(3 tap = 1 call, `blocked=2`) · long-op elapsed · ✓/✖ + `okLabel` ("✓Posted") + asli label wapas ·
error par dobara usable · sync action par koi busy UI nahi · safety timeout (`stale≥1`) ·
**rendered assertions**: `UI.modal`, `UI.drawer` (GRN), `UI2.modal` ke action buttons khud UI.run par +
duplicate click block · PWA bundle mein `PWA.run` (aur purana `⏳ Processing…` hack gayab) ·
purane hacks tree mein nahi · **zero page errors**.

**Sensitivity:** `SENS=1 node tools/test_ui_run.js` (features off) → **17 checks FAIL** = purana behaviour
pakra jata hai.

## 6 ▸ Infra fix (is round pakra gaya, dobara nahi hoga)

Workspace snapshot **symlinks preserve nahi karta** — Chrome ki shared libs ki SONAME links gayab ho gayi thi
(`libatk-1.0.so.0` etc.) aur har browser gate `Failed to launch the browser process` se gir raha tha.
Ilaj: **`tools/fix_chrome_libs.py`** (idempotent symlink repair) aur `tools/verify.sh` ab har run se pehle
khud chala deta hai. `ldd chrome | grep "not found"` → **0**.

## 7 ▸ Regression (is round)

| Gate | Natija |
|---|---|
| `ui-run` (naya) | **34/0** · SENS=1 → 17 FAIL |
| `modals-close` | 91/0 |
| `grn-drawer` | 23/0 |
| `scan-parity` | 29/0 |
| `pay-ledger` (PWA pay path badla) | 24/0 |
| `pwa-overlays` | 124/0 |
| `settings-ui` (App_Config badla) | 16/0 |
| `ai-ui` (AIConfig badla) | 55/0 |
| `ui-polish` | 63/0 |
| `smoke` | 332/0 |
| `tabs` | 656/0 |
| `e2e` / `logic` | 55/0 · 816/0 |

## Verification (is build ka)

`env -u HOME bash tools/verify.sh` → **61 gates · ALL GATES GREEN ✔ (1187s ≈ 20 min)** · log `tmp/verify2510.log`.

## Aage

W2.T3 shared error/retry policy (`UI.errBox` + retry sirf network errors) · W7 call-sites → `API.parallel`
(App_Screens2 49 await / 0 Promise.all · Accounting N+1) · phir W3 dynamic deps, W4 datetime, W5 visibility.
