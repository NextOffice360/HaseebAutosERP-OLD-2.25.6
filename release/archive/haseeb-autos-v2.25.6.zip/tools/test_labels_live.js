/**
 * tools/test_labels_live.js — v2.25.0 — Label designer: TRUE LIVE PREVIEW gate.
 *
 * User ki shikayat (requirement 5):
 *   "Implement a true live preview: every change made in the label designer must
 *    immediately and accurately appear in the preview without requiring
 *    refresh/reload. Ensure generated output matches the designer preview."
 *   "Prevent text, barcodes, QR codes and other elements from overflowing
 *    outside the label/frame boundaries."
 *
 * Ye test asli Chromium mein designer kholta hai aur har control badal kar
 * render ki hui DOM naapta hai (koi static text match nahi — asli pixels).
 *
 *   node tools/test_labels_live.js [file|http]      (default demo/index.html)
 */
'use strict';
const puppeteer = require('puppeteer');
const path = require('path');
const ROOT = path.join(__dirname, '..');
const TARGET = process.argv[2] || ('file://' + path.join(ROOT, 'demo', 'index.html'));

let pass = 0, fail = 0; const ERR = [];
const sleep = ms => new Promise(r => setTimeout(r, ms));
const ok = (n, c, d) => c ? (pass++, console.log('  ✔ ' + n + (d ? '  → ' + d : '')))
  : (fail++, ERR.push(n), console.log('  ✖ ' + n + (d ? '  → ' + d : '')));

/* koi bhi element label frame se bahar? (aur text clip bhi na ho) */
const OVERFLOW_PROBE = `(() => {
  const labs = [...document.querySelectorAll('.print-preview .label')];
  return labs.map(l => {
    const lr = l.getBoundingClientRect();
    let outside = 0, worst = '';
    l.querySelectorAll('*').forEach(c => {
      const r = c.getBoundingClientRect();
      if (r.width <= 0 && r.height <= 0) return;
      if (r.left < lr.left - 1 || r.right > lr.right + 1 || r.top < lr.top - 1 || r.bottom > lr.bottom + 1) {
        outside++; if (!worst) worst = String(c.getAttribute('class') || c.tagName);
      }
    });
    return { w: Math.round(lr.width), h: Math.round(lr.height), outside, worst,
      clipped: (l.scrollWidth > l.clientWidth + 1) || (l.scrollHeight > l.clientHeight + 1),
      bars: l.querySelectorAll('svg rect').length, hr: !!l.querySelector('.lhr') };
  });
})()`;

(async () => {
  console.log('\n\x1b[1mLABEL DESIGNER — LIVE PREVIEW + FRAME FIT\x1b[0m\n');
  const browser = await puppeteer.launch({ args: ['--no-sandbox', '--disable-dev-shm-usage', '--font-render-hinting=none'] });
  const page = await browser.newPage();
  const errs = [];
  page.on('pageerror', e => errs.push(String(e && e.message)));
  await page.setViewport({ width: 1440, height: 900 });
  await page.goto(TARGET, { waitUntil: 'load', timeout: 40000 });
  await sleep(1000);
  if (await page.evaluate(() => !!document.querySelector('#lgUser'))) {
    await page.evaluate(() => {
      document.querySelector('#lgUser').value = 'owner';
      document.querySelector('#lgPass').value = 'admin123';
      document.querySelector('form.login-box').dispatchEvent(new Event('submit', { bubbles: true, cancelable: true }));
    });
  }
  await page.waitForFunction(() => window.App && App.state && App.state.session, { timeout: 15000 });
  await sleep(1200);

  /* ---------------- designer kholें (LABEL) ---------------- */
  const opened = await page.evaluate(() => {
    if (!window.Print2 || !Print2.designer) return false;
    Print2.designer('LABEL', { json: JSON.stringify({ paper: '50x30', title: 'MY SHOP', footer: 'THANK YOU', fontSize: 12 }) }, () => { });
    return true;
  });
  ok('designer khula (LABEL type)', opened, String(opened));
  await sleep(2600);

  const setField = async (labelRe, value) => page.evaluate((re, val) => {
    const cols = [...document.querySelectorAll('.design-left .f-col, .f-col')]
      .filter(c => new RegExp(re, 'i').test((c.textContent || '').trim()));
    const inp = cols[0] && cols[0].querySelector('input,select,textarea');
    if (!inp) return false;
    inp.value = val;
    inp.dispatchEvent(new Event('input', { bubbles: true }));
    inp.dispatchEvent(new Event('change', { bubbles: true }));
    return true;
  }, labelRe, value);

  /* 1) Title → live */
  let r = await setField('^Title', 'LIVE TITLE 42');
  await sleep(1200);
  const hasTitle = await page.evaluate(() => /LIVE TITLE 42/.test((document.querySelector('.print-preview') || {}).innerText || ''));
  ok('Title badalne par preview FORAN update (refresh ke baghair)', r && hasTitle, String(hasTitle));

  /* 2) Font size → scale var (12 se 18 — preview foran bada ho) */
  const readLfs = () => page.evaluate(() => {
    const l = document.querySelector('.print-preview .label');
    return l ? (parseFloat(getComputedStyle(l).getPropertyValue('--lfs')) || 0) : 0;
  });
  await setField('Font size', '12');
  await sleep(900);
  const lfs12 = await readLfs();
  r = await setField('Font size', '18');
  await sleep(1100);
  const lfs18 = await readLfs();
  ok('Font size badalne par label font-scale FORAN change', r && lfs18 > lfs12 && lfs18 > 1.05,
    'font 12 → ' + lfs12 + ' ;  font 18 → ' + lfs18);

  /* 3) Footer / Terms → live */
  await setField('^Footer', 'FOOTER-XYZ');
  await sleep(900);
  await setField('Terms', 'TERMS-ABC');
  await sleep(900);
  const footOk = await page.evaluate(() => /FOOTER-XYZ/.test(document.querySelector('.print-preview').innerText)
    && /TERMS-ABC/.test(document.querySelector('.print-preview').innerText));
  ok('Footer + Terms live preview mein nazar aate hain', footOk, String(footOk));

  /* 4) Show title OFF → gayab */
  r = await setField('Show title', '');
  await page.evaluate(() => {
    const cols = [...document.querySelectorAll('.f-col, label')].filter(c => /Show title/i.test(c.textContent || ''));
    const cb = cols[0] && cols[0].querySelector('input[type=checkbox]');
    if (cb) { cb.checked = false; cb.dispatchEvent(new Event('change', { bubbles: true })); cb.dispatchEvent(new Event('input', { bubbles: true })); }
  });
  await sleep(1200);
  const titleGone = await page.evaluate(() => !/LIVE TITLE 42/.test(document.querySelector('.print-preview').innerText));
  ok('"Show title" off karne par title preview se hat jata hai', titleGone, String(titleGone));

  /* 5) frame-fit: har preset (6) + har size par kuch bhi bahar nahi */
  const presets = await page.evaluate(() => window.Print.LABEL_TEMPLATES.map(t => t.id));
  ok('6 label templates maujood (single source)', presets.length === 6, presets.join(','));

  let allFit = true, fitDetail = [];
  for (let i = 0; i < presets.length; i++) {
    await page.evaluate(idx => {
      const chips = [...document.querySelectorAll('.design-left .chip2')];
      if (chips[idx]) chips[idx].click();
    }, i);
    await sleep(1500);
    const res = await page.evaluate(OVERFLOW_PROBE);
    const bad = res.filter(x => x.outside > 0 || x.clipped);
    if (bad.length) { allFit = false; fitDetail.push(presets[i] + ':' + JSON.stringify(bad[0])); }
    if (i === 0) ok('har label mein barcode symbol + human-readable line',
      res.every(x => x.bars > 20 || x.hr), JSON.stringify(res.map(x => ({ bars: x.bars, hr: x.hr }))));
  }
  ok('saare 6 presets: koi element label frame se bahar nahi / kuch clip nahi',
    allFit, allFit ? '0 overflow' : fitDetail.join(' | '));

  /* 6) preview == print output.
     Design ka faisla: designer ka preview aur asli print output EK hi HTML +
     EK hi CSS se bante hain. Isliye hum preview ka .label clone karke ASLI print
     CSS (Print.baseCss) ke saath ek alag frame mein render karte hain aur
     geometry (font-size, --lfs, bars, human-readable) match karte hain —
     aur ye bhi check karte hain ke print copy mein kuch bahar/clip na ho. */
  const fidelity = await page.evaluate(async () => {
    const prevLabel = document.querySelector('.print-preview .label');
    if (!prevLabel) return { err: 'preview label nahi mila' };
    const css = window.Print.baseCss('A4');
    const clone = prevLabel.outerHTML;
    const ifr = document.createElement('iframe');
    ifr.style.cssText = 'position:fixed;left:-9999px;top:0;width:900px;height:700px;border:0';
    document.body.appendChild(ifr);
    const d = ifr.contentDocument;
    d.open();
    d.write('<!DOCTYPE html><html><head><meta charset="utf-8"><style>' + css + '</style></head><body>' + clone + '</body></html>');
    d.close();
    await new Promise(r => setTimeout(r, 300));
    const pl = d.querySelector('.label');
    const cs = (el, prop) => el ? getComputedStyle(el).getPropertyValue(prop).trim() : '';
    const lr = pl.getBoundingClientRect();
    let outside = 0;
    pl.querySelectorAll('*').forEach(c => {
      const r = c.getBoundingClientRect();
      if (r.width <= 0 && r.height <= 0) return;
      if (r.left < lr.left - 1 || r.right > lr.right + 1 || r.top < lr.top - 1 || r.bottom > lr.bottom + 1) outside++;
    });
    /* asli print pipeline dobara: labelsHtml → print CSS */
    const html = await window.Print.labelsHtml(
      [{ id: 'SMP1', name: 'FLAMINGO 450ML', code: 'FL00000', barcode: '6959375198888', price: 338, currency: 'Rs', unit: 'PCS' }],
      { json: JSON.stringify({ style: 'retail', title: 'MY SHOP', footer: 'THANK YOU', fontSize: 12 }), width: 50, height: 30 });
    const ifr2 = document.createElement('iframe');
    ifr2.style.cssText = 'position:fixed;left:-9999px;top:0;width:900px;height:700px;border:0';
    document.body.appendChild(ifr2);
    const d2 = ifr2.contentDocument;
    d2.open();
    d2.write('<!DOCTYPE html><html><head><meta charset="utf-8"><style>' + css + '</style></head><body>' + html + '</body></html>');
    d2.close();
    await new Promise(r => setTimeout(r, 300));
    const p2 = d2.querySelector('.label');
    const lr2 = p2.getBoundingClientRect();
    let outside2 = 0;
    p2.querySelectorAll('*').forEach(c => {
      const r = c.getBoundingClientRect();
      if (r.width <= 0 && r.height <= 0) return;
      if (r.left < lr2.left - 1 || r.right > lr2.right + 1 || r.top < lr2.top - 1 || r.bottom > lr2.bottom + 1) outside2++;
    });
    const out = {
      cssUsedByBoth: window.Print.baseCss('A4').indexOf('.label .lhr') > -1 && window.Print.LABEL_CSS.indexOf('.label .lbc') > -1,
      prevLfs: cs(prevLabel, '--lfs'), printLfs: cs(pl, '--lfs'),
      prevNameFs: cs(prevLabel.querySelector('.lname'), 'font-size'), printNameFs: cs(pl.querySelector('.lname'), 'font-size'),
      prevBars: prevLabel.querySelectorAll('.lbc svg rect').length, printBars: pl.querySelectorAll('.lbc svg rect').length,
      prevHR: !!prevLabel.querySelector('.lhr'), printHR: !!pl.querySelector('.lhr'),
      printOutside: outside, printClipped: (pl.scrollWidth > pl.clientWidth + 1) || (pl.scrollHeight > pl.clientHeight + 1),
      directTitle: /MY SHOP/.test(p2.innerText), directHR: !!p2.querySelector('.lhr'),
      directOutside: outside2, directClipped: (p2.scrollWidth > p2.clientWidth + 1) || (p2.scrollHeight > p2.clientHeight + 1),
      mm: p2.style.width + 'x' + p2.style.height
    };
    ifr.remove(); ifr2.remove();
    return out;
  });
  const fid = fidelity || {};
  ok('print output aur preview EK hi label CSS + config use karte hain',
    !!fid.cssUsedByBoth && fid.prevLfs === fid.printLfs && fid.prevNameFs === fid.printNameFs &&
    fid.prevBars === fid.printBars && fid.prevHR === fid.printHR,
    JSON.stringify(fid).slice(0, 260));
  ok('print output mein bhi kuch label frame se bahar / clip nahi',
    fid.printOutside === 0 && fid.printClipped === false && fid.directOutside === 0 && fid.directClipped === false &&
    fid.directTitle === true && fid.directHR === true,
    'clone: outside=' + fid.printOutside + ' clipped=' + fid.printClipped +
    '  |  50x30 direct: outside=' + fid.directOutside + ' clipped=' + fid.directClipped +
    ' title=' + fid.directTitle + ' human-readable=' + fid.directHR);

  /* 7) SHEET CASES (A4 / A5) + edge items — req 5:
     "labels must not overflow outside the label/frame" + "output matches preview".
     Sheet mode (A4/A5) par labels apne mm size par rehte hain, ek doosre par nahi
     chadhte, aur page CSS (@page) bhi sahi hoti hai — yahi asli print output hai. */
  const sheets = await page.evaluate(async () => {
    const rows = n => Array.from({ length: n }, (_, i) => ({
      id: 'S' + i, name: 'FLAMINGO 450ML', code: 'FL0000' + i,
      barcode: '69593751988' + (80 + i), price: 338, currency: 'Rs', unit: 'PCS'
    }));
    const render = async (labels, cfg, paper) => {
      const html = await window.Print.labelsHtml(labels, { json: JSON.stringify(cfg), width: 50, height: 30 });
      const css = window.Print.baseCss(paper);
      const ifr = document.createElement('iframe');
      ifr.style.cssText = 'position:fixed;left:-9999px;top:0;width:1000px;height:800px;border:0';
      document.body.appendChild(ifr);
      const d = ifr.contentDocument;
      d.open();
      d.write('<!DOCTYPE html><html><head><meta charset="utf-8"><style>' + css + '</style></head><body>' + html + '</body></html>');
      d.close();
      await new Promise(r => setTimeout(r, 320));
      const ls = [...d.querySelectorAll('.label')];
      const rects = ls.map(l => l.getBoundingClientRect());
      let outside = 0, clipped = 0, hr = 0; const uniqW = {};
      ls.forEach((l, i) => {
        const lr = rects[i];
        l.querySelectorAll('*').forEach(c => {
          const r = c.getBoundingClientRect();
          if (r.width <= 0 && r.height <= 0) return;
          if (r.left < lr.left - 1 || r.right > lr.right + 1 || r.top < lr.top - 1 || r.bottom > lr.bottom + 1) outside++;
        });
        if ((l.scrollWidth > l.clientWidth + 1) || (l.scrollHeight > l.clientHeight + 1)) clipped++;
        if (l.querySelector('.lhr')) hr++;
        uniqW[Math.round(lr.width)] = 1;
      });
      let overlap = 0;
      for (let i = 0; i < rects.length; i++) {
        for (let j = i + 1; j < rects.length; j++) {
          const a = rects[i], b = rects[j];
          if (a.left < b.right - 1 && b.left < a.right - 1 && a.top < b.bottom - 1 && b.top < a.bottom - 1) overlap++;
        }
      }
      const txt = (d.body.innerText || '').replace(/\s+/g, ' ').slice(0, 140);
      ifr.remove();
      return { n: ls.length, outside: outside, clipped: clipped, hr: hr, overlap: overlap,
        widths: Object.keys(uniqW).map(Number), txt: txt,
        page: /@page\{size:A4 portrait;margin:8mm\}/.test(css) ? 'A4'
          : (/@page\{size:A5 portrait;margin:8mm\}/.test(css) ? 'A5' : '?') };
    };
    const cfg = { style: 'retail', title: 'MY SHOP', footer: 'THANK YOU', fontSize: 12 };
    const a4 = await render(rows(24), cfg, 'A4');
    const a5 = await render(rows(12), cfg, 'A5');
    const nobar = await render([{ id: 'NB', name: 'NO BARCODE ITEM', code: 'SKU-1', barcode: '', price: 100, currency: 'Rs', unit: 'PCS' }], cfg, 'A4');
    const longname = await render([{ id: 'LN', name: 'FLAMINGO SUPER EXTRA LONG PRODUCT NAME 450ML PREMIUM QUALITY EDITION SPECIAL', code: 'FL99999', barcode: '6959375198888', price: 12345, currency: 'Rs', unit: 'PCS' }], cfg, 'A4');
    return { a4: a4, a5: a5, nobar: nobar, longname: longname };
  });
  ok('A4 sheet: 24 labels — koi element apne frame se bahar/clip nahi, labels overlap nahi karte',
    sheets.a4.n === 24 && sheets.a4.outside === 0 && sheets.a4.clipped === 0 && sheets.a4.overlap === 0 && sheets.a4.page === 'A4',
    JSON.stringify({ n: sheets.a4.n, outside: sheets.a4.outside, clipped: sheets.a4.clipped, overlap: sheets.a4.overlap, page: sheets.a4.page, hr: sheets.a4.hr }));
  ok('A5 sheet: 12 labels — wahi 0 overflow + sahi @page CSS',
    sheets.a5.n === 12 && sheets.a5.outside === 0 && sheets.a5.clipped === 0 && sheets.a5.overlap === 0 && sheets.a5.page === 'A5',
    JSON.stringify({ n: sheets.a5.n, outside: sheets.a5.outside, clipped: sheets.a5.clipped, overlap: sheets.a5.overlap, page: sheets.a5.page }));
  ok('sheet par label apna mm size hi rakhta hai (preview jaisa — stretch nahi hota)',
    sheets.a4.widths.length === 1 && Math.abs(sheets.a4.widths[0] - 189) <= 4,
    'A4 label width px = ' + JSON.stringify(sheets.a4.widths) + ' (50mm ~ 189px)');
  ok('barcode ke bagair item: label phir bhi banta hai (code human-readable) + 0 overflow',
    sheets.nobar.n === 1 && sheets.nobar.outside === 0 && sheets.nobar.clipped === 0 && /SKU-1/.test(sheets.nobar.txt),
    JSON.stringify({ n: sheets.nobar.n, outside: sheets.nobar.outside, clipped: sheets.nobar.clipped, txt: sheets.nobar.txt.slice(0, 60) }));
  ok('bohat lamba product naam: text frame ke andar rehta hai (0 overflow / 0 clip)',
    sheets.longname.n === 1 && sheets.longname.outside === 0 && sheets.longname.clipped === 0,
    JSON.stringify({ outside: sheets.longname.outside, clipped: sheets.longname.clipped, txt: sheets.longname.txt.slice(0, 60) }));

  ok('designer run mein zero page errors', errs.length === 0, JSON.stringify(errs).slice(0, 200));

  await browser.close();
  console.log('\n═══════════════════════════════════════════════════════════');
  console.log(`  LABELS (live preview)   PASS: ${pass}   FAIL: ${fail}`);
  if (fail) ERR.forEach(e => console.log('   ✖ ' + e));
  console.log('═══════════════════════════════════════════════════════════');
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error('✖ ' + (e && e.stack || e)); process.exit(1); });
