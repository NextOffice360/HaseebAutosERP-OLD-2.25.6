# Haseeb Autos — v2.25.9 CHANGELOG

**Date:** 2026-09-24 · **Version:** `2.25.9` (Utils.gs ▸ `VERSION`)
**Base:** v2.25.8 → is build mein **shared fetch core** (W2.T1): dedupe · TTL cache · invalidation ·
retry · parallel. Yehi wo cheez hai jo audit ke findings **E1/E4/E8** ka core ilaaj hai
(aap ka req 1 aur 2: "slow data fetching" + "global reusable shared logic, page-by-page nahi").

---

## 1 ▸ `API.call` ka naya shared core (ek jagah, poori app ke liye)

Pehle har call site apna pattern rakhti thi (438 sites). Ab teen shared behaviours `API.call` ke andar:

### (a) IN-FLIGHT DEDUPE — sirf READS
Same action + same payload jab pehli call **abhi chalu ho**, to doosri network call **nahi hoti** —
dono callers ko wahi promise/data milta hai. Ye double-render / double-tap wali zaya calls khatam
karta hai (audit: `dups` counter isi ko naap raha tha).
**Writes par kabhi nahi** — do save = do save (data loss ka khatra nahi).

### (b) TTL CACHE + INVALIDATION
`DEFAULT_TTL` mein wo reads jo stable hain: `config.defs` · `config.menu` · `config.list` (120s),
`system.settings.get` (60s), `items.facets` · `warehouse.list` (60–120s).
* Per-call control: `API.call('items.list', {}, { cacheTtl: 30000 })` ya `{ noCache: true }`.
* **Har kaamyab WRITE par cache khud-ba-khud saaf** (stale data kabhi nahi) — `API.invalidate(prefix)`
  manual bhi mojood hai. `API.cacheSize()` se maujooda entries ginti.

### (c) RETRY — sirf READS, sirf network/timeout error
Backoff + jitter (`260ms × attempt + random`), default **1 retry**, `{ retries: 3 }` se barha sakte
hain, `{ retry: false }` se band. Validation/session errors par **koi retry nahi**; writes par **koi
retry nahi** (duplicate post se bachao).

### (d) `API.parallel(tasks, limit = 6)`
Sequential `await` waterfall (audit E8: `App_Screens2` mein 49 await / 0 `Promise.all`) ka
hathiyar — tasks ek sath chalte hain, concurrency cap ke sath, aur results index-wise laute hain.
Call-sites ko W7 mein is par shift karenge.

Sab features `API._features = { dedupe, cache, retry }` se off/on ho sakte hain (sensitivity proof
ke liye) — default sab **on**.

## 2 ▸ Naapa hua asar (demo/local, mock transport)

| Scenario | Pehle (cache OFF) | Ab (cache ON) |
|---|---|---|
| 3 × `renderNav()` → `config.menu` network calls | **3** | **1** |
| 3 identical parallel reads (dedupe test) | 3 mock calls | **1** |
| items → reports → items | har dafa `config.list` fresh | 1 call cache se |

Live GAS par har call ka apna round-trip (1–3s) hota hai — is liye yehi fix **"button dabane par
1 minute"** ke asli sabab (waterfall + repeat calls) ko khatam karta hai; baqi hissa
(N+1 `expenses.approve`, heavy screens ka parallelisation) W2.T2/T7 aur W7 mein.

## 3 ▸ Naya gate: `api-core` (16 checks, 6s)

`tools/test_api_core.js` — dedupe (3 parallel → 1 mock call, writes exempt, stats.dedupesServed) ·
cache (hit, `noCache` bypass, `DEFAULT_TTL` config.menu) · invalidation (write ke baad 0 entries) ·
retry (network error par 3 attempts success; validation par 1 attempt; write par 0 retry) ·
`API.parallel` (3 kaam, inflight ≥ 2) · zero page errors.

**Sensitivity proven:** `SENS=1 node tools/test_api_core.js` → features off → **6 checks FAIL**
(`dedupe: mock calls=3`, `cacheHits=0`, `invalidation before=0`, `DEFAULT_TTL hits=0` …).

## 4 ▸ Gates: 58 → **60**

Regression (is round): `api-core` 16/0 · `session-guard` 15/0 · `api-instrument` 14/0 · `e2e` 55/0 · `logic` 816/0 ·
`smoke` 332/0 (129s) · `tabs` 656/0 · `modals-close` ✔ · `sidebar-states` 19/0.

## 5 ▸ Crash fix: null session par UI girna band (shared guard)

Full-verify ke dauraan `smoke` gate crash hua aur asli bug nikla:
logout / session-expiry ke baad `App.state.session` **null** hota hai, magar shop quick-dialog
(khuli cash-session wala) aur account menu seedha `.fullName` parh rahe the →

```
TypeError: Cannot read properties of null (reading 'fullName')   → poori dialog gayab
```

**Fix (shared, ek hi jagah se):** `App.sessionMeta()` — App_Core.html.
Har module yahi se safe values leta hai: `ok · name · initial · role · group · userId · token`
(null par `name=''`, `initial='U'`, `role='—'`). 8 call-sites shift hue:
`App_Boot` ×4 (avatar, account menu, close-shop summary, changePassword) · `App_Dashboards` ·
`App_POS` · `App_POS2` · `App_Lang`. Baaki sab jagahon par pehle se guard tha (audit: 0 unguarded baaqi).

**Naya gate `session-guard`** (`tools/test_session_guard.js`, asli browser, **15/0 · 8.6s**):
logged-in meta, null-session fallbacks, shop quick-dialog (khuli session + null app-session),
account menu — teeno par **page-error 0**.
**Sensitivity:** guards hata kar puranay direct access par → gate CRASH (`shopQuickDialog` TypeError) = pakra jata hai.

## 6 ▸ Test flake do (root cause + hardening)

* `smoke` boot fixed **300 ms** par tha; jsdom boot ka login screen 280–404 ms leta hai → race
  (2 identical runs = 66 FAIL). Ab `waitFor(fn, ms)` poll helper (boot + orders + takeorder) aur
  `.mo-search` na milne par graceful fail (poora gate crash nahi hota) → **332/0**.
* `audit_tabs` boot bhi fixed 400 ms par tha → poll kiya; aur `ALLOWED` mein `skel`/`skel-wrap` add
  (data >200 ms lene par skeleton bars "blank block" gin liye ja rahe the) → **656/0**.
* Doosri full-verify mein `align` bhi isi race se gira (fixed 400 ms ke baad `#lgUser.value`).
  Audit: **12 gate** isi pattern par the → naya **`tools/_harness.js`** (`waitForPage`/`waitForDom`
  poll + `login(page)`/`loginDom(doc, win)`) banaya aur sab shift kiye; page-specific fixed sleeps gaye.
  Re-check: `align` 35/0 · `settings-ui` 16/0 · `auth-startup` 21/0 · `demand` 13/0 ·
  `grn-drawer` 23/0 · `salesman-stock` 10/0 · `labels-live` 30/0 · `ui-polish` 63/0 · `punchlist` ✔ · `layout` ✔.

## 7 ▸ Load par teen aur flake (sab test-side, sab reproducibly fix)

* `modals-close`: standalone **91/0 (24s)** magar full run mein 5 checks gire (167s = 3x slow) —
  stacked-modals scenario Esc ke baad fixed `sleep(700)` par assert karta tha. Ab
  `waitStack(pred, 4000)` poll (setup + har Esc) → documented contract wahi, intezar theek.
* `scan-parity`: standalone **29/0 (30s)**, full run mein 5 GRN/PO scan checks gire (63s).
  Diagnostic ne pakra: `got="" act=INPUT.f-input ipk-scan-in focusOK=true` (5/5 attempts) —
  load mein app scan row re-render kar deti hai, `handle.type()` ka handle detach ho jata hai aur
  characters khali input par girte hain. Ab `page.keyboard.type()` + focused-element ka poll
  (`value === code` aur `activeElement` scan field ho), phir Enter → 29/0 ×2.
* `ui` gate: fixed 400 ms ke baad `#lgUser.value` → crash. Ab shared `loginDom()` → 3s mein ✔.

## 8 ▸ Regression-proof lint

`tools/check_harness_lint.js` ab **`tools/check.sh` (gate `check`)** ka hissa hai — do rules:
jo tool login values set kare usay `_harness` chahiye; jo login DOM chhue usay harness ya
`page.type()`/`waitForFunction()` chahiye. Aaj **71 tools, 0 violations**.

## Verification (is build ka)

`env -u HOME bash tools/verify.sh` → **60 gates · ALL GATES GREEN ✔ (1193s ≈ 20 min)** · log `tmp/verify259d.log`.

(Is version ke dauraan 4 full runs chale: 59/2 → 59/1 → 57/3 → **60/0**. Har failure ka root cause nikaal kar fix hua — upar sections 5–8.)

## Aage (roadmap)

W2.T1b `App.sessionMeta` (ho gaya) · W2.T2 `UI.run`/`UI.busy` (action-specific spinner + duplicate-click block) · W2.T3 error/retry UI
(`UI.errBox`) · W2.T4 long-op progress → phir W3 dynamic deps (Country→State→City, AI provider),
W4 timestamps + configurable date/time, W5 visibility + **backend/API-level** protection.
Tafseel: `TODO-PERF-SHARED-UI.md`.
