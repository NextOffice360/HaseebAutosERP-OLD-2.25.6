# Haseeb Autos — v2.25.11 CHANGELOG

**Date:** 2026-09-24 · **Version:** `2.25.11` (Utils.gs ▸ `VERSION`)
**Base:** v2.25.10 (action-level busy) → is build mein **W2.T3: shared error / retry policy**
(aap ke spec ka wo hissa: *"retry sirf tab jab munasib ho, aur user ko kabhi na lage ke pata nahi kya hua"*).

---

## 1 ▸ Audit (pehle root cause, phir code)

| Kya mila | Kitna |
|---|---|
| `UI.toast(e.message, 'err')` — backend ka **raw technical text** seedha user ko | **150+ call-sites** |
| `UI.fail` / inline error box / retry action — **kuch nahi tha** | 0 |
| Error classification (network vs validation vs auth vs conflict) | 0 |

Asli shikayat ki jarh: backend aksar kehta tha *"…then retry."* ya *"Please retry."* — magar
**karne ko Retry ka koi button nahi tha**, aur validation ghalti (jaise qty 0, field khaali) par bhi
"retry" ka kehna **ghalat guidance** hai (retry se woh masla hal nahi hota — fields theek karne hote hain).

## 2 ▸ Naya shared error policy (App_Core.html — ek jagah, poori app)

| Cheez | Kaam |
|---|---|
| **`UI.errKind(err)`** | 7 kinds: `offline` · `network` · `auth` · `validation` · `conflict` · `server` · `unknown` — har kind ka `title`, `hint`, `icon` aur **`retryable`** flag |
| **`UI.errText(err)`** | User-friendly line: `REQUEST_TIMEOUT:` jaise codes hat jate hain aur **"then retry / please retry / reload" jaisi guidance wale jumle** nikal jate hain (kyunki ab asli button hota hai). `conflict/auth/server/unknown` par seedha title + hint (raw text "Technical tafseel" mein rehta hai) |
| **`UI.errBox(host, err, opts)`** | ACTION ke paas **thaira hua** inline box: icon + title + "aage kya karein" hint + `<details>` technical tafseel + buttons |
| **`UI.fail(err, opts)`** | Ek call mein: classified toast (+ Retry button agar jaiz ho) **aur** inline box (host ho to) |
| **`UI.toast(..., 'err')`** | Ab khud classified — **150+ purane call-sites bina chhue** sahi text dikhate hain; `{ action: { label, onClick } }` se toast par asli button |

### RETRY SIRF JAB JAIZ HO (aap ki shart)
* `network` · `offline` · `server` · `conflict` → **"↻ Dobara koshish karein"** button (aur woh wahi kaam dobara chalata hai).
* `validation` · `auth` · `unknown` → **Retry button NAHI** — balki asli guidance ("fields durust karein", "dobara login karein").

### WRITE par extra hifazat (double-post se bachao
* `write: true` wale actions (GRN post, PO save, settings save, AI save, **POS sale**) par:
  * warning box: *"Ye GRN post ka kaam tha — pehle list refresh kar ke dekhein ke kaam ho chuka hai ya nahi, phir dobara karein."*
  * **⟳ List refresh** button (toast se lekar inline box tak) — taake user blindly dobara post na kare.
* Stats: `UI.errStats()` → `classified · retryable · blockedRetry · retryClicked · writeWarned`.

## 3 ▸ `UI.run` ka error path (W2.T2 + W2.T3 ka jorr)

Fail hone par ab **khud-ba-khud**:
1. button apni asli halat par wapas (busy state saaf),
2. **inline error box** modal/drawer/offcanvas ke body mein (footer ke button se body tak `_errHostFor` pohanchta hai),
3. Retry button → wahi kaam dobara (`UI.run` ke through — yani busy/dup-block sab dobara lagta hai),
4. write errors par refresh warning.

`UI.modal` · `UI.drawer` · `UI2.modal` · `UI2.offcanvas` ke **har action** par yeh sab khud-ba-khud.

## 4 ▸ Ek asli bug bhi pakra gaya (gate ne)

Action ke andar error throw hone par promise **unhandled rejection** ban rahi thi — browser console mein
`Uncaught (in promise)`. Ab modal/drawer/offcanvas wiring, errBox ka Retry button aur toast ka action
teenon jagah rejection **sambhali** jati hai (warning log + user ko UI.fail se feedback pehle hi mil chuka hota hai).

## 5 ▸ PWA bundle (Pwa_Shell.html) — wahi contract

`PWA.errKind/errText/errBox/fail/errStats` + `PWA.run` ka error path + POS "✓ Complete" par `write: true`
(yani sale timeout hone par "pehle refresh karein" warning + Refresh button) + `.err-box` CSS.

## 6 ▸ Naya gate: `ui-err` (30 checks, ~6s)

`tools/test_ui_err.js` — ① 7 kinds + retryable flags sahi · ② friendly text (code hat gaya, "then retry" gaya,
technical stack ki jagah title+hint) · ③ purana raw call-site bhi classified + toast par asli Retry button jo
click par chalta hai · ④ `errBox`: render, title/hint/details, retryable par Retry, validation par **NAHI**,
write par warning + refresh button + counter · ⑤ `UI.run` error path: khud box, retry se calls=2, button phansa nahi ·
⑥ PWA bundle (minified) mein exports + CSS + write flag · ⑦ zero page errors.

**Sensitivity:** `SENS=1 node tools/test_ui_err.js` → **5 checks FAIL** (features off = purana raw behaviour).

## 7 ▸ Regression (is round)

`ui-err` **30/0** · `ui-run` 34/0 · `smoke` 332/0 · `modals-close` 91/0 · `check` (lint) ✔
· gates **61 → 62**.

## §8 ▸ Test flake root-cause (scan typing, teesri baar — ab deterministic)

`scan-parity` full run mein phir gira (157s vs standalone 30s). Diagnostic ne pakra:
focus **sahi** tha (`activeScan=true`) magar value **khali** (`got=""` 5/5), aur
`keyboard.insertText()` bhi land nahi hota tha (har scan mein fallback). Wajah: slow/loaded run mein
app scan row ko **re-render** kar deti hai aur typing ke darmiyan characters detached node par girte hain.
Field khud normal text input hai (readonly nahi) → ye **harness ki limitation**, app ka bug nahi.

Fix: scan ko **deterministic** simulate kiya jata hai — jo kaam HID wedge aakhir mein DOM par karta hai:
`value` set + `input`/`change` events, phir Enter (app ka asli contract: input par process, Enter par commit).
Ab **29/0 ×2** (aur full run mein bhi green).

## Verification (is build ka)

`env -u HOME bash tools/verify.sh` → **62 gates · ALL GATES GREEN ✔ (1195s ≈ 20 min)** · log `tmp/verify2511c.log`.

(Is version ke dauraan 3 full runs: pehla `icons` par gira — PWA mein escape-sequence emoji literal ki jagah likhe the (`\u{1F4F6}`) aur icons gate har icon ko aik-codepoint maangta hai → sab literal emoji kar diye; doosra `scan-parity` par gira — scan typing ka tareeqa load mein flake kar raha tha (neeche §8); teesra **62/0 green**.)

## Aage

**W7** call-sites → `API.parallel` (App_Screens2: 49 await / 0 Promise.all · Accounting N+1 `App_Accounting.html:448`)
· phir **W3** dynamic dependencies (Country→State→City, AI provider fields) · **W4** datetime system ·
**W5** visibility (backend-enforced).
